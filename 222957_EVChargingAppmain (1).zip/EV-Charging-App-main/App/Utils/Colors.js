export default{
    PRIMARY:'#0BC224',
    GRAY:'#898989',
    WHITE:'#ffffff',
    BLACK:'#000000',
    WHITE_TRANSP:'#ffffff87'
}