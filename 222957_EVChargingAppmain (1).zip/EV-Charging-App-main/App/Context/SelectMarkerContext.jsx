import { createContext } from "react";

export const SelectMarkerContext=createContext(null);